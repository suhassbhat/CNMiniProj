# CNMiniProject

Run the following to install the requirements:
```
pip install virtualenv
virtualenv venv
.\venv\Scripts\activate.ps1 
pip install -r requirements.txt
```

Run the following to build the app:
```
pyinstaller driver.spec
```